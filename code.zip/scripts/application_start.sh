#!/bin/bash
 cd /
 sudo /home/ec2-user/.nvm/versions/node/v16.8.0/bin/node server.js